﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Collections;

namespace JamieCahnCE08_Remake
{
    class Program
    {
        List<string[]> Records = new List<string[]>();
        List<string[]> RealRecords = new List<string[]>();

        static void Main(string[] args)
        {
            Program instance = new Program();
            bool running = true;
            List<string> fieldNames = new List<string>();
            Dictionary<string, string[]> dictionaryDataList = new Dictionary<string, string[]>();

            Dictionary<string, List<string>> Data;


            while (running)
            {
                Console.Clear();
                Console.WriteLine("Menu");
                Console.WriteLine("Which file would you like to load: ");
                Console.WriteLine("1. DataFile1");
                Console.WriteLine("2. DataFile2");
                Console.WriteLine("3. DataFile3");
                Console.WriteLine("4. Exit");
                Console.Write("Please Select a datafile to load: ");
                string input = Console.ReadLine().ToLower();






                switch (input)
                {
                    case "1":
                    case "datafile1":
                    case "data file 1":
                        {
                            instance.MakeList(fieldNames);
                            instance.LoadFileOne(fieldNames);
                            instance.PrintRecords();
                            instance.ConvertRecordsToJSON(fieldNames);
                            Utility.PauseBeforeContinuing();


                        }
                        break;
                    case "2":
                    case "datafile2":
                    case "data file 2":
                        {
                            instance.MakeList(fieldNames);
                            instance.LoadFileTwo(fieldNames);
                            instance.PrintRecords();
                            instance.ConvertRecordsToJSON(fieldNames);
                            Utility.PauseBeforeContinuing();
                        }
                        break;
                    case "3":
                    case "datafile3":
                    case "data file 3":
                        {
                            instance.MakeList(fieldNames);
                            instance.LoadFileThree(fieldNames);
                            instance.PrintRecords();
                            instance.ConvertRecordsToJSON(fieldNames);
                            Utility.PauseBeforeContinuing();
                        }
                        break;
                    case "4":
                    case "exit":
                        {
                            running = false;
                        }
                        break;
                    default:
                        {
                            Utility.Invalid();
                        }
                        break;
                }
            }
        }

        private List<string> MakeList(List<string> dataList)
        {

            using (StreamReader sr = new StreamReader(File.OpenRead("DataFieldsLayout.txt")))
            {

                string fileName = sr.ReadToEnd();
                string[] tmp = fileName.Split('\n');
                for (int i = 0; i < tmp.Length - 1; i++)
                {
                    dataList.Add(tmp[i]);
                }
            }
            return dataList;
        }


        private void LoadFileOne(List<string> fieldNames)
        {
            using (StreamReader sr = new StreamReader(File.OpenRead("DataFile1.txt")))
            {
                Records.Clear();
                RealRecords.Clear();

                sr.ReadLine();

                for (int j = 0; j < 100; j++)
                {
                    RealRecords.Add(sr.ReadLine().Split('|'));
                }
            }
        }

        private void LoadFileTwo(List<string> fieldNames)
        {
            using (StreamReader sr = new StreamReader(File.OpenRead("DataFile2.txt")))
            {
                Records.Clear();
                RealRecords.Clear();

                sr.ReadLine();

                for (int j = 0; j < 100; j++)
                {
                    RealRecords.Add(sr.ReadLine().Split('|'));
                }
            }
        }

        private void LoadFileThree(List<string> fieldNames)
        {
            using (StreamReader sr = new StreamReader(File.OpenRead("DataFile3.txt")))
            {
                Records.Clear();
                RealRecords.Clear();

                sr.ReadLine();

                for (int j = 0; j < 100; j++)
                {
                    RealRecords.Add(sr.ReadLine().Split('|'));
                }
            }
        }

        public void PrintRecords()
        {
            Console.Clear();
            Console.WriteLine("File Converted.");
            Utility.PauseBeforeContinuing();
        }

        private void ConvertRecordsToJSON(List<string> fieldNames)
        {
            Console.Clear();

            using (StreamWriter sw = new StreamWriter("datafile.json"))
            {

                sw.WriteLine("[");
                for (int i = 0; i < RealRecords.Count; i++)
                {
                    sw.WriteLine("[");
                    for (int j = 0; j < fieldNames.Count; j++)
                    {


                        sw.WriteLine("{");
                        if (j + 1 == fieldNames.Count)
                        {
                            sw.WriteLine($" \"{fieldNames[j]}\" : \"{RealRecords[i][j]}\"}}");
                        }
                        else
                        {
                            sw.WriteLine($" \"{fieldNames[j]}\" : \"{RealRecords[i][j]}\"}},");
                        }

                    }

                    if (i + 1 == RealRecords.Count)
                    {
                        sw.WriteLine("]");
                    }
                    else
                    {
                        sw.WriteLine("],");
                    }
                }
                sw.WriteLine("]");
            }





        }







    }
}

