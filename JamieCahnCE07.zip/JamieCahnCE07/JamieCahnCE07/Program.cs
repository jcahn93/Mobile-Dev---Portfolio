﻿using System;
using System.Collections.Generic;

namespace JamieCahnCE07
{
    class Program
    {
        static void Main(string[] args)
        {
            bool running = true;
            List<Employee> employeeList;
            employeeList = new List<Employee>();
            Program instance = new Program();

            while (running)
            {
                Console.Clear();
                Console.WriteLine("Employee Tracker");
                Console.WriteLine("----------------");
                Console.WriteLine("1. Add Employee");
                Console.WriteLine("2. Remove Employee");
                Console.WriteLine("3. Display Payroll");
                Console.WriteLine("4. Exit");
                Console.Write("Please Select an item: ");
                string input = Console.ReadLine().ToLower();

                switch (input)
                {
                    case "1":
                    case "add employee":
                        {
                            instance.AddEmployee(employeeList);

                            employeeList.Sort();
                        }
                        break;
                    case "2":
                    case "remove employee":
                        {
                            instance.RemoveEmployee(employeeList);
                        }
                        break;
                    case "3":
                    case "display payroll":
                        {
                            instance.DisplayPayroll(employeeList);
                        }
                        break;
                    case "4":
                    case "exit":
                        {
                            running = false;
                        }
                        break;
                    default:
                        {
                            Utility.Invalid();
                        }
                        break;
                }

                Utility.PauseBeforeContinuing();
            }






        }

        private void AddEmployee(List<Employee> employeeList)
        {
            bool addingEmployee = true;

            Console.WriteLine("What is the first name of the new employee: ");
            string firstName = Console.ReadLine().ToLower();

            Console.WriteLine("What is the last name of the new employee: ");
            string lastName = Console.ReadLine().ToLower();

            string name = lastName + ", " + firstName;


            Console.WriteLine("What is the address for the new employee: ");
            string address = Console.ReadLine().ToLower();


            while (addingEmployee)
            {

                Console.Clear();
                Console.WriteLine("Which type of employee would you like to create: (Please choose from the options below: ");
                Console.WriteLine("1. Full Time");
                Console.WriteLine("2. Part Time");
                Console.WriteLine("3. Contractor");
                Console.WriteLine("4. Salaried");
                Console.WriteLine("5. Manager");
                Console.Write("Please Choose an Option: ");
                string input = Console.ReadLine().ToLower();



                switch (input)
                {
                    case "1":
                    case "full time":
                        {
                            decimal howMuch = Utility.HowMuchMoney();

                            FullTime ft = new FullTime(name, address, howMuch);

                            employeeList.Add(ft);
                            addingEmployee = false;
                        }
                        break;
                    case "2":
                    case "part time":
                        {
                            decimal howMuch = Utility.HowMuchMoney();
                            decimal howMany = Utility.HowManyHours();

                            PartTime pt = new PartTime(name, address, howMuch, howMany);

                            employeeList.Add(pt);
                            addingEmployee = false;
                        }
                        break;
                    case "3":
                    case "contractor":
                        {
                            decimal howMuch = Utility.HowMuchMoney();
                            decimal howMany = Utility.HowManyHours();
                            decimal noBenefitsBonus = Utility.GetValue(0m, .15m, "What is the no benefit bonus for this contractor (Please answer this .10 or .15): ");

                            Contractor ct = new Contractor(name, address, howMuch, howMany, noBenefitsBonus);

                            employeeList.Add(ct);
                            addingEmployee = false;
                        }
                        break;
                    case "4":
                    case "salaried":
                        {
                            decimal employeeSalary = Utility.GetValue(0m, 9999999999999m, "What is the salary for this employee: ");

                            Salaried sal = new Salaried(name, address, employeeSalary);

                            employeeList.Add(sal);
                            addingEmployee = false;
                        }
                        break;
                    case "5":
                    case "manager":
                        {
                            decimal employeeSalary = Utility.GetValue(0m, 9999999999999m, "What is the salary for this employee: ");
                            decimal bonus = Utility.GetValue(0m, 9999999999999999m, "What is the bonus for this employee: ");
                            Manager mgr = new Manager(name, address, employeeSalary, bonus);

                            employeeList.Add(mgr);
                            addingEmployee = false;
                        }
                        break;
                    default:
                        {
                            Utility.Invalid();
                        }
                        break;
                }
            }

        }

        private void RemoveEmployee(List<Employee> employeeList)
        {
            if (employeeList.Count < 1)
            {
                Console.WriteLine("No employees to remove.");

            }
            else
            {
                for (int i = 0; i < employeeList.Count; i++)
                {
                    Console.WriteLine(i + 1 + " " + employeeList[i].Name);
                }

                int input = Utility.GetInt(0, employeeList.Count, "Which Employee would you like to remove: ");




                employeeList.RemoveAt(input - 1);
            }
        }

        private void DisplayPayroll(List<Employee> employeeList)
        {
            if (employeeList.Count < 1)
            {
                Console.WriteLine("No employees to display.");
            }
            else
            {
                for (int i = 0; i < employeeList.Count; i++)
                {
                    Console.WriteLine(i + 1 + " Name: " + employeeList[i].Name + " Address: " + employeeList[i].Address + " $" + employeeList[i].CalculatePay());
                }
            }
        }
    }
}
