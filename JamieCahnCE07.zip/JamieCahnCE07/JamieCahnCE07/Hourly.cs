﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JamieCahnCE07
{
    class Hourly : Employee
    {
        private decimal _payPerHour;
        private decimal _hoursPerWeek;

        public Hourly()
        {
            
            _payPerHour = 0;
            _hoursPerWeek = 0;
        }

        public Hourly(string name, string address, decimal payPerHour, decimal hoursPerWeek) 
        {
            Name = name;
            Address = address;
            _payPerHour = payPerHour;
            _hoursPerWeek = hoursPerWeek;
        }

        public decimal PayPerHour
        {
            get
            {
                return _payPerHour;
            }
            set
            {
                _payPerHour = value;
            }
        }

        public decimal HoursPerWeek
        {
            get
            {
                return _hoursPerWeek;
            }
            set
            {
                _hoursPerWeek = value;
            }
        }

        public override decimal CalculatePay()
        {
            return (_payPerHour * _hoursPerWeek * 52);
        }
    }
}
