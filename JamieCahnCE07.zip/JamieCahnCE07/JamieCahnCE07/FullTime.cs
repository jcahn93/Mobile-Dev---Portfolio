﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JamieCahnCE07
{
    class FullTime : Hourly
    {
        public FullTime(string name, string address, decimal payPerHour)
        {
            Name = name;
            Address = address;
            PayPerHour = payPerHour;
            HoursPerWeek = 40;
        }


        

    }
}
