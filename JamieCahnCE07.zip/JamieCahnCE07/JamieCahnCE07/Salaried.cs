﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JamieCahnCE07
{
    class Salaried : Employee
    {
        private decimal _salary;

        public Salaried()
        {
            _salary = 0;
        }

        public Salaried(string name, string address, decimal salary)
        {
            Name = name;
            Address = address;
            _salary = salary;
        }

        public decimal Salary
        {
            get
            {
                return  _salary;
            }
            set
            {
                _salary = value;
            }
        }

        public override decimal CalculatePay()
        {
            return _salary;

        }






    }
}
