﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JamieCahnCE07
{
    class Employee : IComparable
    {
        private string _name;
        private string _address;

        public Employee()
        {
            _name = "";
            _address = "";
        }

        public Employee(string name, string address)
        {
            _name = name;
            _address = address;
        }

        public string Name
        {
            get
            {
                return _name;
            }
            set
            {
                _name = value;
            }
        }
        
        public string Address
        {
            get
            {
                return _address;
            }
            set
            {
                _address = value;
            }
        }

        public virtual decimal CalculatePay()
        {
            decimal i = 0;

            return i;
        }

        public int CompareTo(object employee)
        {
           Employee emp = (Employee) employee;

            return string.Compare(_name, emp.Name);
        }


    }
}
