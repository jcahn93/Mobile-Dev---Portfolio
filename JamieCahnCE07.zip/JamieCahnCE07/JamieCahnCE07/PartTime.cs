﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JamieCahnCE07
{
    class PartTime : Hourly
    {
        public PartTime(string name, string address, decimal payPerHour, decimal hoursPerWeek)
        {
            Name = name;
            Address = address;
            PayPerHour = payPerHour;
            HoursPerWeek = hoursPerWeek;
        }

        public override decimal CalculatePay()
        {
            return (PayPerHour * HoursPerWeek * 52);
        }
    }
}
