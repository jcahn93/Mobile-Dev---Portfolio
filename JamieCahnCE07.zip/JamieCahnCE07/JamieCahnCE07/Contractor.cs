﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JamieCahnCE07
{
    class Contractor : Hourly
    {
        private decimal _noBenefitsBonus;

        public Contractor()
        {
            _noBenefitsBonus = 0;
        }

        public Contractor(string name, string address, decimal payPerHour, decimal hoursPerWeek, decimal noBenefitsBonus)
        {
            Name = name;
            Address = address;
            PayPerHour = payPerHour;
            HoursPerWeek = hoursPerWeek;
            _noBenefitsBonus = noBenefitsBonus;
        }

        public decimal NoBenefitsBonus
        {
            get
            {
                return _noBenefitsBonus;
            }
            set
            {
                _noBenefitsBonus = value;
            }
        }

        public override decimal CalculatePay()
        {
            decimal i = PayPerHour * HoursPerWeek * 52;

            return i + (i * _noBenefitsBonus);
        }

    }
}
