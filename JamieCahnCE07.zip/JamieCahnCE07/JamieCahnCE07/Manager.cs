﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JamieCahnCE07
{
    class Manager : Salaried
    {
        private decimal _bonus;

        public Manager()
        {
            _bonus = 0;
        }

        public Manager(string name, string address, decimal salary, decimal bonus)
        {
            Name = name;
            Address = address;
            Salary = salary;
            _bonus = bonus;
        }

        public decimal Bonus
        {
            get
            {
                return _bonus;
            }
            set
            {
                _bonus = value;
            }
        }

        public override decimal CalculatePay()
        {
            decimal i = Salary;

            return i + _bonus;

        }


    }
}
