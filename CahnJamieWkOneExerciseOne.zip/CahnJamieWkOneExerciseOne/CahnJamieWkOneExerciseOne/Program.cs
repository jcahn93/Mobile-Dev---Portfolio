﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CahnJamieWkOneExerciseOne
{
    class Program
    {
        static void Main(string[] args)
        {

            //variables
            bool running = true;
            Program instance = new Program();
            List<string> fruitsNVeggies = new List<string>();

            //main menu

            //Create The List
            instance.CreateList(fruitsNVeggies);

            while (running)
            {
                Console.Clear();
                Console.WriteLine("Main Menu");
                Console.WriteLine("1. Display List (Unsorted)");
                Console.WriteLine("2. Alphabetize List (A-Z)");
                Console.WriteLine("3. Alphabetize List (Z-A)");
                Console.WriteLine("4. Randomize Deletion of List");
                Console.WriteLine("5. Regenerate List");
                Console.WriteLine("6. Exit");
                Console.Write("Please choose an item (1-6): ");
                string UserInput = Console.ReadLine().ToLower();

                //switch on userInput
                switch (UserInput)
                {
                    case "1":
                        {
                            fruitsNVeggies = instance.MenuOne(fruitsNVeggies);
                        }
                        break;
                    case "2":
                        {
                            fruitsNVeggies = instance.MenuTwo(fruitsNVeggies);
                        }
                        break;
                    case "3":
                        {
                            fruitsNVeggies = instance.MenuThree(fruitsNVeggies);
                        }
                        break;
                    case "4":
                        {
                            instance.MenuFour(fruitsNVeggies);
                        }
                        break;
                    case "5":
                        {
                            instance.CreateList(fruitsNVeggies);
                        }
                        break;
                    case "6":
                        {
                            running = false;
                        }
                        break;
                    default:
                        {
                            Utility.Invalid();
                        }
                        break;
                }
                Console.WriteLine();
                Utility.PauseBeforeContinuing();
            }
        }

        private List<string> MenuOne(List<string> fruitsNVeggies)
        {
            for (int i = 0; i <= fruitsNVeggies.Count -1; i++)
            {
                Console.WriteLine(fruitsNVeggies[i].ToString());
            }
            return fruitsNVeggies;
        } //menu item one - display the list

        private List<string> MenuTwo(List<string> fruitsNVeggies)
        {
            fruitsNVeggies.Sort();
            for (int i = 0; i <= fruitsNVeggies.Count -1; i++)
            {
                Console.WriteLine(fruitsNVeggies[i].ToString());
            }
            return fruitsNVeggies;
        } //menu item two - (a-z)

        private List<string> MenuThree(List<string> fruitsNVeggies)
        {
            fruitsNVeggies.Reverse();
            for (int i = 0; i <= fruitsNVeggies.Count - 1; i++)
            {
                Console.WriteLine(fruitsNVeggies[i].ToString());
            }
            return fruitsNVeggies;
        } //menu item three - (z-a)

        private void MenuFour(List<string> fruitsNVeggies) //menu item four - randomize then delete
        {
            Random number = new Random();
            int rNum = 0;

            while (true)
            {
                if (fruitsNVeggies.Count != 0)
                {
                    for (int i = 0; i <= fruitsNVeggies.Count - 1; i++)
                    {
                        Console.Write($"{fruitsNVeggies[i].ToString()} ");
                    }

                    fruitsNVeggies.RemoveAt(rNum);
                }
                else
                {
                    Console.WriteLine("There are no items left in the list.");
                    break;
                }
                Console.WriteLine();
                rNum = number.Next(0, fruitsNVeggies.Count);
            }
        }

        private void RandomList(List<string> fruitsNVeggies)
        {
            List<string> fnv = new List<string>();
            var rnd = new Random();
            fnv = fruitsNVeggies.OrderBy(x => rnd.Next()).ToList();
            fnv = fnv.OrderBy(x => rnd.Next()).ToList();
        } //create a random list

        private List<string> CreateList(List<string> fruitsNVeggies) //create the initial list
        {
            fruitsNVeggies.Add("apples");
            fruitsNVeggies.Add("bananas");
            fruitsNVeggies.Add("grapes");
            fruitsNVeggies.Add("beans");
            fruitsNVeggies.Add("carrots");
            fruitsNVeggies.Add("artichoke");
            fruitsNVeggies.Add("broccoli");
            fruitsNVeggies.Add("sprouts");
            fruitsNVeggies.Add("cabbage");
            fruitsNVeggies.Add("onions");
            fruitsNVeggies.Add("avocado");
            fruitsNVeggies.Add("cucumber");
            fruitsNVeggies.Add("fennel");
            fruitsNVeggies.Add("eggplant");
            fruitsNVeggies.Add("leeks");
            fruitsNVeggies.Add("lettuce");
            fruitsNVeggies.Add("red pepper");
            fruitsNVeggies.Add("tomato");
            fruitsNVeggies.Add("zucchini");
            fruitsNVeggies.Add("turnip");
            return fruitsNVeggies;
        }
    }
}
