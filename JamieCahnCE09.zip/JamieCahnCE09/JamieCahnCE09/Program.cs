using System;
using MySql.Data.MySqlClient;
using System.IO;
using System.Data;
using System.Collections.Generic;

namespace JamieCahnCE09
{
    class Program
    {
        MySqlConnection _con = null;
        static void Main(string[] args)
        {
            Program instance = new Program();
            List<DVD> inventory = new List<DVD>();
            List<DVD> shoppingCart = new List<DVD>();
            string DVD_Title = "";
            string priceString = "";
            decimal price = 0;
            string publicRatingString = "";
            float publicRating = 0f;
            bool running = true;
            bool result;




            instance._con = new MySqlConnection();
            instance.Connect();

            DataTable data = instance.QueryDB("SELECT DVD_Title, Price, publicRating FROM dvd LIMIT 20");
            DataRowCollection rows = data.Rows;

            for (int i = 0; i < data.Rows.Count; i++)
            {
                DVD_Title = rows[i][0].ToString();
                priceString = rows[i][1].ToString();
                try
                {
                    price = Convert.ToDecimal(priceString);
                }
                catch(OverflowException)
                {
                    Console.WriteLine("The conversion was unsuccessful.");
                }
                publicRatingString = rows[i][2].ToString();
                try
                {
                    publicRating = float.Parse(publicRatingString);
                }
                catch (OverflowException)
                {
                    Console.WriteLine("The conversion was unsuccessful.");
                }

                DVD tmpDVD = new DVD(DVD_Title, price, publicRating);

                inventory.Add(tmpDVD);
            }

            instance._con.Close();

            while (running)
            {
                Console.Clear();
                Console.WriteLine("Menu");
                Console.WriteLine("1. View Inventory");
                Console.WriteLine("2. View Shopping Cart");
                Console.WriteLine("3. Add DVD to Cart");
                Console.WriteLine("4. Remove DVD from Cart");
                Console.WriteLine("5. Exit");
                Console.Write("Please enter a selection: ");
                string input = Console.ReadLine().ToLower();

                switch (input)
                {
                    case "1":
                    case "view inventory":
                        {
                            if (inventory.Count > 0)
                            {
                                for (int i = 0; i < inventory.Count; i++)
                                {
                                    Console.WriteLine((i + 1) + $". DVD Title: {inventory[i].DVD_Title} Price: {inventory[i].Price} Rating: {inventory[i].Rating}");
                                    
                                }
                                Console.WriteLine("Press any key to continue. ");
                                Console.ReadKey();
                            }
                            else
                            {
                                Console.WriteLine("There are no items in the store's inventory.");
                                Console.WriteLine();
                                Console.WriteLine("Press any key to continue. ");
                                Console.ReadKey();
                            }
                            
                        }
                        break;
                    case "2":
                    case "view shopping cart":
                        {
                            if (shoppingCart.Count > 0)
                            {
                                for (int i = 0; i < shoppingCart.Count; i++)
                                {
                                    Console.WriteLine((i + 1) + $". DVD Title: {shoppingCart[i].DVD_Title} Price: {shoppingCart[i].Price} Rating: {shoppingCart[i].Rating}");
                                }
                                Console.WriteLine("Press any key to continue. ");
                                Console.ReadKey();
                            }
                            else
                            {
                                Console.WriteLine("There are no items in your shopping cart.");
                                Console.WriteLine();
                                Console.WriteLine("Press any key to continue. ");
                                Console.ReadKey();
                            }

                        }
                        break;
                    case "3":
                    case "add dvd to cart":
                        {
                            if (inventory.Count > 0)
                            {
                                for (int i = 0; i < inventory.Count; i++)
                                {
                                    Console.WriteLine((i + 1) + $". DVD Title: {inventory[i].DVD_Title} Price: {inventory[i].Price} Rating: {inventory[i].Rating}");
                                }
                                bool validationAdd = true;
                                while (validationAdd)
                                {
                                    Console.WriteLine("Which DVD would you like to add to your cart(Please select a number corresponding to your selection):  ");
                                    string addDVDInput = Console.ReadLine();
                                    int addDVDInputInt;
                                
                                    if ((result = Int32.TryParse(addDVDInput, out addDVDInputInt)) && addDVDInputInt <= inventory.Count)
                                    {
                                        shoppingCart.Add(inventory[addDVDInputInt - 1]);
                                        inventory.RemoveAt(addDVDInputInt - 1);
                                        validationAdd = false;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid Entry. Please Try Again");
                                    }
                                }

                            }
                            else
                            {
                                Console.WriteLine("There are no items in the store's inventory. ");
                                Console.WriteLine();
                                Console.WriteLine("Press any key to continue. ");
                                Console.ReadKey();
                            }


                        }
                        break;
                    case "4":
                    case "remove dvd from cart":
                        {
                            if (shoppingCart.Count > 0)
                            {
                                for (int i = 0; i < shoppingCart.Count; i++)
                                {

                                    Console.WriteLine((i + 1) + $". DVD Title: {shoppingCart[i].DVD_Title} Price: {shoppingCart[i].Price} Rating: {shoppingCart[i].Rating}");
                                    Console.WriteLine();
                                }


                                bool validationRemove = true;
                                while (validationRemove)
                                {
                                    Console.WriteLine("Which DVD would you like to add to your cart(Please select a number corresponding to your selection):  ");
                                    string removeDVDInput = Console.ReadLine();
                                    int removeDVDInputInt;

                                    if (result = Int32.TryParse(removeDVDInput, out removeDVDInputInt) && removeDVDInputInt <= shoppingCart.Count)
                                    {
                                        inventory.Add(shoppingCart[removeDVDInputInt - 1]);
                                        shoppingCart.RemoveAt(removeDVDInputInt - 1);
                                        validationRemove = false;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Invalid Entry. Please Try Again");
                                    }
                                }
                            }
                            else
                            {
                                Console.WriteLine("There are no items in your shopping cart.");
                                Console.WriteLine();
                                Console.WriteLine("Press any key to continue. ");
                                Console.ReadKey();
                            }
                        }
                        break;
                    case "5":
                    case "exit":
                        {
                            running = false;
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("Invalid Input, Please Try Again.");
                            Console.WriteLine("Press any key to continue.");
                            Console.ReadKey();
                        }
                        break;
                }
            }
            Console.WriteLine("\nPress any key to continue.");
            Console.ReadKey();
        }

        private void Connect()
        {
            BuildConString();
            try
            {
                _con.Open();
                Console.WriteLine("Connection Successful.");
            }
            catch(MySqlException e)
            {
                string msg = "";
                switch (e.Number)
                {
                    case 0:
                        {
                            msg = e.ToString();
                        }
                        break;
                    case 1042:
                        {
                            msg = "Can't Resolve Host Address.\n" + _con.ConnectionString;
                        }
                        break;
                    case 1045:
                        {
                            msg = "Invalid Username/Password";
                        }
                        break;
                    default:
                        {
                            msg = e.ToString();
                        }
                        break;
                }

                Console.WriteLine(msg);
            }
        }

        private void BuildConString()
        {
            string ip = "";

            using (StreamReader sr = new StreamReader("C:/VFW/connect.txt"))
            {
                ip = sr.ReadLine();
            }

            string conString = $"Server={ip};";
            conString += "uid=dbsAdmin;";
            conString += "pwd=password;";
            conString += "database=exampleDatabase;";
            conString += "port=8889";


            _con.ConnectionString = conString;
        }

        //private void BuildConStringFull(string user, string password, string dbName)
        //{
        //    MySqlConnectionStringBuilder connString = new MySqlConnectionStringBuilder();
        //    connString.Append($"Server=");
        //    connString.Append($"{ReadIpFromFile};");
        //    connString.Append($"uid={user};");
        //    connString.Append($"pwd={password}; ");
        //    connString.Append($"database={dbName};");
        //    connString.Append($"port=8889");

        //    Console.WriteLine($"Connection String: {connString.ToString()}");
        //    _conn.ConnectionString = connString.ToString();
        //} 
        //Incase I want to use connection.txt (Does not currently work)

        DataTable QueryDB(string query)
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _con);

            DataTable data = new DataTable();

            adapter.SelectCommand.CommandType = CommandType.Text;
            adapter.Fill(data);

            return data;
        }

        //private string ReadIpFromFile()
        //{
        //    string serverIP = "Failed to load IP from file";
        //    try
        //    {
        //        using (StreamReader sr = new StreamReader("C:/VFW/connection.txt"))
        //        {
        //            serverIP = sr.ReadLine();
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        throw;
        //    }

        //    return serverIP;
        //}


    }
}
