﻿using System;
using System.Collections.Generic;
using System.Text;

namespace JamieCahnCE09
{
    class DVD
    {
        private string _title;
        private decimal _price;
        private float _rating;

        public DVD(string DVD_Title, decimal price, float publicRating)
        {
            _title = DVD_Title;
            _price = price;
            _rating = publicRating;
        }
        public string DVD_Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
            }
        }

        public decimal Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }

        public float Rating
        {
            get
            {
                return _rating;
            }
            set
            {
                _rating = value;
            }
        }

    }
}
