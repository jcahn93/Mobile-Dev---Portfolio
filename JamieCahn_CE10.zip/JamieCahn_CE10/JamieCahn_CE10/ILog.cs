﻿namespace JamieCahn_CE10
{
    interface ILog
    {
        void ToCartLog(string msg);
        void CompletePurchaseLog(string msg, decimal total);
        void log(string msg);
        void ToStoreLog(string msg);
        void ChangeUser(string msg);

    }
}