﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JamieCahn_CE10
{
    class InventoryItems
    {
        string _title;
        decimal _price;
        string _releaseDate;

        public InventoryItems(string itemTitle, decimal price, string releaseDate)
        {
            _title = itemTitle;
            _price = price;
            _releaseDate = releaseDate;
        }
        public string itemTitle
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
            }
        }

        public decimal Price
        {
            get
            {
                return _price;
            }
            set
            {
                _price = value;
            }
        }

        public string releaseDate
        {
            get
            {
                return _releaseDate;
            }
            set
            {
                _releaseDate = value;
            }
        }






    }
}
