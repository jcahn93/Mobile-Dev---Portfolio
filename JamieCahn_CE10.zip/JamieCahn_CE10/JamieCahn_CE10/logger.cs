﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace JamieCahn_CE10
{
    class logger : ILog
    {
        public void log(string msg)
        {
            using (StreamWriter sw = new StreamWriter("log.txt"))
            {
                sw.WriteLine(msg);

            }
        }
        public void CompletePurchaseLog(string msg, decimal total)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine($"Customer {msg} has checked out for a total of ${total}.");

            }
        }

        public void ToStoreLog(string msg)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine($"Item: {msg} is being added to Store Inventory and removed from Users Cart.");

            }
        }

        public void ToCartLog(string msg)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine($"Item: {msg} is being added to Cart and removed from Store Inventory.");

            }
        }

        public void ChangeUser(string msg)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine($"Current Customer changed to: {msg}.");
            }
        }
    }
}
