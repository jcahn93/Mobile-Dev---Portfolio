﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JamieCahn_CE10
{
    class Customers
    {
        string _firstName = "";
        string _lastName = "";
        string _name = "";
        int _age = 0;
        string _phoneNumber = "";
        string _emailAddress = "";
        List<InventoryItems> _customerCart;

        public Customers(string firstName, string lastName, int age, string phoneNumber, string emailAddress, List<InventoryItems> customerCart)
        {
            _firstName = firstName;
            _lastName = lastName;
            _name = firstName + " " + lastName;
            _age = age;
            _phoneNumber = phoneNumber;
            _emailAddress = emailAddress;
            _customerCart = customerCart;
        }

        public string firstName
        {
            get { return _firstName; } set { _firstName = value; }
        }

        public string lastName
        {
            get { return _lastName; } set { _lastName = value; }
        }

        public int age
        {
            get { return _age; } set { _age = value; }
        }

        public string phoneNumber
        {
            get { return _phoneNumber; } set { _phoneNumber = value; }
        }
        
        public string emailAddress
        {
            get { return _emailAddress; } set { _emailAddress = value; }
        }

        public List<InventoryItems> customerCart
        {
            get { return _customerCart; } set { _customerCart = value; }
        }

    }
}
