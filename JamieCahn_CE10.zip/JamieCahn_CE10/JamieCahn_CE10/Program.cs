﻿using System;
using System.Collections.Generic;
using MySql.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.IO;
using System.Data;

namespace JamieCahn_CE10
{
    class Program
    {
        MySqlConnection _con = null;
        logger logFile = new logger();

        static void Main(string[] args)
        {
            bool running = true;
            string item_title;
            string priceString;
            decimal price = 0;
            string releaseDate;

            Program instance = new Program();
            Customers currentCustomer = null;
            List<InventoryItems> storeInventory = new List<InventoryItems>();
            List<InventoryItems> customerCart = new List<InventoryItems>();
            Dictionary<string, Customers> customers = new Dictionary<string, Customers>();
            

            instance._con = new MySqlConnection();
            instance.Connect();

            DataTable data = instance.QueryDB("SELECT title, retailPrice, releaseDate FROM item LIMIT 50");
            DataRowCollection rows = data.Rows;

            for (int i = 0; i < data.Rows.Count; i++)
            {
                item_title = rows[i][0].ToString();
                priceString = rows[i][1].ToString();
                try
                {
                    price = Convert.ToDecimal(priceString);
                }
                catch (OverflowException)
                {
                    Console.WriteLine("The conversion was unsuccessful.");
                }

                releaseDate = rows[i][2].ToString();

                InventoryItems tmpItem = new InventoryItems(item_title, price, releaseDate);

                storeInventory.Add(tmpItem);
            }

            instance._con.Close();

            while (running)
            {
                Console.Clear();
                Console.WriteLine("Main Menu");
                Console.WriteLine("1. Select Current Shopper or Create a new Shopper");
                Console.WriteLine("2. View Store Inventory");
                Console.WriteLine("3. View Cart");
                Console.WriteLine("4. Add Item to Cart");
                Console.WriteLine("5. Remove Item from Cart");
                Console.WriteLine("6. Complete Purchase");
                Console.WriteLine("7. Exit");
                Console.Write("Please choose from the selection above: ");
                string input = Console.ReadLine().ToString();

                switch (input)
                {
                    case "1":
                    case "select current shopper":
                    case "create new shopper":
                        {
                            currentCustomer = instance.SelectCustomer(customers, currentCustomer);
                            
                        }
                        break;
                    case "2":
                    case "view store inventory":
                        {
                            instance.ViewStoreInventory(storeInventory);
                        } 
                        break;
                    case "3":
                    case "view cart":
                        {
                            if (currentCustomer == null)
                            {
                                Utility.NoCustomer();
                            }
                            else
                            {
                                if (currentCustomer.customerCart.Count <= 0)
                                {
                                    Console.WriteLine("There are no items in your cart.");
                                }
                                else
                                {
                                    instance.ViewCart(currentCustomer, customers);
                                }
                            }
                        }
                        break;
                    case "4":
                    case "add item to cart":
                        {
                            if (currentCustomer == null)
                            {
                                Utility.NoCustomer();
                            }
                            else
                            {
                                if (storeInventory.Count <= 0)
                                {
                                    Console.WriteLine("There are no items in the store.");
                                }
                                else
                                {
                                    instance.AddItemsToCart(currentCustomer, storeInventory);
                                }
                            }
                        }
                        break;
                    case "5":
                    case "remove item from cart":
                        {
                            if (currentCustomer == null)
                            {
                                Utility.NoCustomer();
                            }
                            else
                            {
                                if (currentCustomer.customerCart.Count <= 0)
                                {
                                    Console.WriteLine("There are no items in your cart.");
                                }
                                else
                                {
                                    instance.RemoveItemFromCart(storeInventory, currentCustomer);
                                }
                            }
                        }
                        break;
                    case "6":
                    case "complete purchase":
                        {
                            if (currentCustomer == null)
                            {
                                Utility.NoCustomer();
                            }
                            else
                            {
                                instance.CompletePurchase(currentCustomer, customers);
                            }
                        }
                        break;
                    case "7":
                    case "exit": 
                        {
                            running = false;
                        }
                        break;
                    default:
                        {
                            Utility.Invalid();
                        }
                        break;
                }
                Utility.PauseBeforeContinuing();
            }
        }

        private Customers SelectCustomer(Dictionary<string, Customers> customers, Customers currentCustomer)
        {
            if (customers.Count <= 0)
            {
                Console.WriteLine("What is the customers first name: ");
                string firstName = Console.ReadLine().ToLower();
                Console.WriteLine("What is the customers last name: ");
                string lastName = Console.ReadLine().ToLower();
                int age = Utility.GetInt(1, 120, "What is the customers age?");
                Console.WriteLine("What is the customer's phone number?");
                string phoneNumber = Console.ReadLine().ToLower();
                Console.WriteLine("What is the customer's email address?");
                string emailAddress = Console.ReadLine().ToLower();

                List<InventoryItems> customerCart = new List<InventoryItems>();
                Customers tmpCustomer = new Customers(firstName, lastName, age, phoneNumber, emailAddress, customerCart);

                string fullName = tmpCustomer.lastName + ", " + tmpCustomer.firstName;

                customers.Add(firstName, tmpCustomer);

                currentCustomer = tmpCustomer;
                logFile.ChangeUser(fullName);

            }
            else
            {
                Console.WriteLine("Would you like to create a new customer, or select from one that is already created.");
                Console.WriteLine("1. New Customer");
                Console.WriteLine("2. Existing Customer");
                string input = Console.ReadLine();
                bool running = true;

                while (running)
                {
                    switch (input)
                    {
                        case "1":
                        case "new":
                        case "new customer":
                            {
                                Console.WriteLine("What is the customers first name: ");
                                string firstName = Console.ReadLine().ToLower();
                                Console.WriteLine("What is the customers last name: ");
                                string lastName = Console.ReadLine().ToLower();
                                int age = Utility.GetInt(1, 120, "What is the customers age?");
                                Console.WriteLine("What is the customer's phone number?");
                                string phoneNumber = Console.ReadLine().ToLower();
                                Console.WriteLine("What is the customer's email address?");
                                string emailAddress = Console.ReadLine().ToLower();

                                List<InventoryItems> customerCart = new List<InventoryItems>();
                                Customers tmpCustomer = new Customers(firstName, lastName, age, phoneNumber, emailAddress, customerCart);

                                string fullName = tmpCustomer.lastName + ", " + tmpCustomer.firstName;

                                customers.Add(firstName, tmpCustomer);

                                currentCustomer = tmpCustomer;
                                logFile.ChangeUser(fullName);
                            }
                            break;
                        case "2":
                        case "existing":
                        case "existing customer":
                            {
                                for (int i = 0; i < customers.Count; i++)
                                {
                                    Console.WriteLine($"{customers.ElementAt(i).Key}");
                                }

                                Console.WriteLine("Which customer would you like to select: ");
                                string customerSelectInput = Console.ReadLine().ToLower();

                                if (customers.ContainsKey(customerSelectInput))
                                {
                                    currentCustomer = customers[customerSelectInput];
                                    logFile.ChangeUser(currentCustomer.lastName + ", "+ currentCustomer.firstName);
                                }

                            }
                            break;
                    }
                    running = false;
                }
            }
            return currentCustomer;
        }

        private void ViewStoreInventory(List<InventoryItems> storeInventory)
        {
            Console.WriteLine("Current Store Inventory");
            Console.WriteLine("-----------------------------------------");
            for (int i = 0; i < storeInventory.Count; i++)
            {
                Console.WriteLine($"Title: {storeInventory[i].itemTitle}");
                Console.WriteLine($"Release Date: {storeInventory[i].releaseDate}");
                Console.WriteLine($"Price: {storeInventory[i].Price}");
                Console.WriteLine("-----------------------------------------");
            }
        }

        private void ViewCart(Customers currentCustomer, Dictionary<string, Customers> customers)
        {
            Console.WriteLine($"{currentCustomer.firstName} {currentCustomer.lastName}'s Cart");
            Console.WriteLine("-----------------------------------------");
            for (int i = 0; i < currentCustomer.customerCart.Count; i++)
            {
                Console.WriteLine($"Title: {currentCustomer.customerCart[i].itemTitle}");
                Console.WriteLine($"Release Date: {currentCustomer.customerCart[i].releaseDate}");
                Console.WriteLine($"Price: ${currentCustomer.customerCart[i].Price}");
                Console.WriteLine("-----------------------------------------");
            }
        }

        private void AddItemsToCart(Customers currentCustomer, List<InventoryItems> storeInventory)
        {

            //Display Store Inventory
            Console.WriteLine("Current Store Inventory");
            Console.WriteLine("-----------------------------------------");
            for (int i = 0; i < storeInventory.Count; i++)
            {
                Console.WriteLine($"{i + 1}.");
                Console.WriteLine($"Title: {storeInventory[i].itemTitle}");
                Console.WriteLine($"Release Date: {storeInventory[i].releaseDate}");
                Console.WriteLine($"Price: ${storeInventory[i].Price}");
                Console.WriteLine("-----------------------------------------");
            }

            int userChoice = Utility.GetInt(0, storeInventory.Count, "Which item would you like to add?");

            //Add item to users cart and delete item from store's inventory
            logFile.ToCartLog(((storeInventory[userChoice - 1]).itemTitle).ToString());
            currentCustomer.customerCart.Add(storeInventory[userChoice - 1]);
            storeInventory.RemoveAt(userChoice - 1);
            
        }

        private void RemoveItemFromCart(List<InventoryItems> storeInventory, Customers currentCustomer)
        {
            Console.WriteLine("Current Customer Cart");
            Console.WriteLine("-----------------------------------------");
            for (int i = 0; i < currentCustomer.customerCart.Count; i++)
            {
                Console.WriteLine($"{i + 1}.");
                Console.WriteLine($"Title: {currentCustomer.customerCart[i].itemTitle}");
                Console.WriteLine($"Release Date: {currentCustomer.customerCart[i].releaseDate}");
                Console.WriteLine($"Price: {currentCustomer.customerCart[i].Price}");
                Console.WriteLine("-----------------------------------------");
            }

            int userChoice = Utility.GetInt(0, currentCustomer.customerCart.Count, "Which item would you like to remove?");

            //Remove item from users cart and add item to store's inventory
            logFile.ToStoreLog(((currentCustomer.customerCart[userChoice - 1]).itemTitle).ToString());
            storeInventory.Add(currentCustomer.customerCart[userChoice - 1]);
            currentCustomer.customerCart.RemoveAt(userChoice - 1);

        }

        private void CompletePurchase(Customers currentCustomer, Dictionary<string, Customers> customers)
        {
            //Display Customer Cart
            Console.Clear();
            Console.WriteLine("Current Customer Cart");
            Console.WriteLine("-----------------------------------------");
            for (int i = 0; i < currentCustomer.customerCart.Count; i++) 
            {
                Console.WriteLine($"Title: {currentCustomer.customerCart[i].itemTitle}");
                Console.WriteLine($"Release Date: {currentCustomer.customerCart[i].releaseDate}");
                Console.WriteLine($"Price: {currentCustomer.customerCart[i].Price}");
                Console.WriteLine("-----------------------------------------");
            }

            //logic =)
            decimal totalOrderPrice = 0.00m;
            decimal currentPrice = 0.00m;
            for (int i = 0; i < currentCustomer.customerCart.Count; i++)
            {
                totalOrderPrice = currentCustomer.customerCart[i].Price + currentPrice;
            }

            //Ask user if they would like to check out.

            Console.WriteLine("Are you ready to check out?");
            Console.WriteLine("1. Yes");
            Console.WriteLine("2. No");
            string input = Console.ReadLine().ToLower();
            bool running = true;
            while (running)
            switch (input)
            {
                case "1":
                case "yes":
                case "y":
                    {
                        Console.WriteLine($"Thank you for shopping with us today {currentCustomer.firstName}. Your total is: {totalOrderPrice}");

                            logFile.CompletePurchaseLog((currentCustomer.firstName).ToString(), totalOrderPrice);


                        customers.Remove(currentCustomer.firstName);
                        currentCustomer = null;
                        running = false;
                    }
                    break;
                case "2":
                case "no":
                case "n":
                    {
                        running = false;
                    }
                    break;
                default:
                    {
                        Console.WriteLine("Please choose a valid selection");
                    }
                    break;

            }


        }

        private void Connect()
        {
            BuildConString();
            try
            {
                _con.Open();
                Console.WriteLine("Connection Successful.");
            }
            catch (MySqlException e)
            {
                string msg = "";
                switch (e.Number)
                {
                    case 0:
                        {
                            msg = e.ToString();
                        }
                        break;
                    case 1042:
                        {
                            msg = "Can't Resolve Host Address.\n" + _con.ConnectionString;
                        }
                        break;
                    case 1045:
                        {
                            msg = "Invalid Username/Password";
                        }
                        break;
                    default:
                        {
                            msg = e.ToString();
                        }
                        break;
                }

                Console.WriteLine(msg);
            }
        } 

        private void BuildConString()
        {
            string ip = "";

            using (StreamReader sr = new StreamReader("C:/VFW/connect.txt"))
            {
                ip = sr.ReadLine();
            }

            string conString = $"Server={ip};";
            conString += "uid=dbsAdmin;";
            conString += "pwd=password;";
            conString += "database=exampleDatabase;";
            conString += "port=8889";


            _con.ConnectionString = conString;
        }

        DataTable QueryDB(string query)
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _con);

            DataTable data = new DataTable();

            adapter.SelectCommand.CommandType = CommandType.Text;
            adapter.Fill(data);

            return data;
        }

    }
}
