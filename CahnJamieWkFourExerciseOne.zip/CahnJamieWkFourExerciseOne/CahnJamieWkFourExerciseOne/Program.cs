﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CahnJamieWkFourExerciseOne
{
    class Program
    {
        static void Main(string[] args)
        {
            //variables
            bool running = true;
            List<string> madLibs = new List<string>();
            Program instance = new Program();


            while (running)
            {
                //menu
                Console.Clear();
                Console.WriteLine("Mad Libs Menu");
                Console.WriteLine("-------------");
                Console.WriteLine();
                Console.WriteLine("Would you like to help me finish the puzzle: ");
                Console.WriteLine("1. Yes");
                Console.WriteLine("2. No");
                Console.WriteLine("3. Exit");
                Console.Write("Please choose a selection: ");

                string uInput = Console.ReadLine().ToLower();
                switch (uInput)
                {
                    case "1":
                    case "yes":
                    case "y":
                        {
                            instance.FinishPuzzle(madLibs);
                            Console.WriteLine("Ready to read the story? Press any key to continue...");
                            Console.ReadKey();
                            Console.Clear();
                            instance.ReadStory(madLibs);
                        }
                        break;
                    case "2":
                    case "no":
                    case "n":
                        {
                            Console.WriteLine("Well shucks..... okay I guess I'll just wait till you want to help me...");
                        }
                        break;
                    case "3":
                    case "exit":
                        {
                            running = false;
                        }
                        break;
                    default:
                        {
                            Console.WriteLine("Invalid Input, Please Try Again.");
                        }
                        break;
                }
            }

            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

        private List<string> FinishPuzzle(List<string> madLibs)
        {
            //hints
            string adjective = "(hint: a word or phrase naming an attribute, added to or grammatically related to a noun to modify or describe it.)";
            string noun = "(hint: a person, place or thing.)";
            string verb = "(hint: a word used to descrive an action, state, or occurence, and forming the main part of the predicate of a sent3ence, such as hear, become, happen.)";
            string adverb = "(hint: a word or phrase that modifies or qualifies an adjective, verb, or other adverb or a word group, expressing a relation of place, time, circumstance, manner, cause, degree, etc.)";

            //user input
            Console.WriteLine($"Please type in an adjective {adjective}: ");
            string uInput1 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput1);

            Console.WriteLine($"Please type in a noun {noun}: ");
            string uInput2 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput2);

            Console.WriteLine($"Please type in a past tense verb {verb}: ");
            string uInput3 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput3);

            Console.WriteLine($"Please type in an adverb {adverb}: ");
            string uInput4 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput4);

            Console.WriteLine($"Please type in an adjective {adjective}: ");
            string uInput5 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput5);

            Console.WriteLine($"Please type in a noun {noun}: ");
            string uInput6 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput6);

            Console.WriteLine($"Please type in a noun {noun}: ");
            string uInput7 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput7);

            Console.WriteLine($"Please type in an adjective {adjective}: ");
            string uInput8 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput8);

            Console.WriteLine($"Please type in a verb {verb}: ");
            string uInput9 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput9);

            Console.WriteLine($"Please type in an adverb {adverb}: ");
            string uInput10 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput10);

            Console.WriteLine($"Please type in a past tense verb {verb}: ");
            string uInput11 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput11);

            Console.WriteLine($"Please type in an adjective {adjective}: ");
            string uInput12 = Console.ReadLine().ToUpper();
            madLibs.Add(uInput12);

            Console.Clear();
            Console.WriteLine("Thank you for helping me finish this puzzle >.>");
            return madLibs;
        }

        private void ReadStory(List<string> madLibs)
        {
            Console.Clear();
            Console.WriteLine("Mad Libs Worksheet");
            Console.WriteLine("------------------");
            Console.WriteLine("A Day at the Zoo!!");
            Console.WriteLine();
            Console.WriteLine($"Today I went to the Zoo. I say a {madLibs[0]} {madLibs[1]} jumping up and down in its tree\n\r" +
                $"He {madLibs[2]} {madLibs[3]} through the large tunnel that led to its {madLibs[4]} {madLibs[5]}.\n\r" +
                $"I got some peanuts and passed them through the cage to a gigantic gray {madLibs[6]} towering above my head.\n\r" +
                $"Feeding that animal made me hungry. I went to get a {madLibs[7]} scoop of ice cream. It filled my stomach.\n\r" +
                $"Afterwards I had to {madLibs[8]} {madLibs[9]} to catch our bus. When I got home I {madLibs[10]} my mom for a\n\r" +
                $"{madLibs[11]} day at the zoo.");

            Console.WriteLine();
            Console.WriteLine("Thanks for helping me! You made it WAY more entertaining then I could have!");
            Console.WriteLine();
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

    }
}
