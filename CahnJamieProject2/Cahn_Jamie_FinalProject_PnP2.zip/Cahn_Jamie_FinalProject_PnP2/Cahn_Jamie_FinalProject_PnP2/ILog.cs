﻿namespace Cahn_Jamie_FinalProject_PnP2
{
    interface ILog
    {
        void UserLogin(Users user);
        void CompletePurchase(Drivers driver, Users user, Resturants resturant);
        void GetDriver(Drivers driver);
        void CurrentResturant(Resturants resturant);
        void Order(string msg);
        void Error(string msg);
    }
}