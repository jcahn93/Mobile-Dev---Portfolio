﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cahn_Jamie_FinalProject_PnP2
{
    class Resturants
    {
        public string ResturantName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string PhoneNumber { get; set; }
        public string Rating { get; set; }



        public Resturants(string resturantName, string address, string city, string state, string zip, string phoneNumber, string rating)
        {
            ResturantName = resturantName;
            Address = address;
            City = city;
            Zip = zip;
            PhoneNumber = phoneNumber;
            Rating = rating;
        }

    }
}
