﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace JamieCahnCE08
{
    class Data
    {
        Dictionary<string, string> dataDictionary = new Dictionary<string, string>();
    }
}
