﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cahn_Jamie_FinalProject_PnP2
{
    class Utility
    {
        public static void Invalid()
        {
            Console.WriteLine("Invalid Input, Please Try Again");
            Console.ReadKey();
        }

        public static void InvalidLogin()
        {
            Console.WriteLine("Invalid Username/Password");
        }

        public static void PressAnyKeyToContinue()
        {
            Console.WriteLine("Press any key to continue...");
            Console.ReadKey();
        }

    }
}
