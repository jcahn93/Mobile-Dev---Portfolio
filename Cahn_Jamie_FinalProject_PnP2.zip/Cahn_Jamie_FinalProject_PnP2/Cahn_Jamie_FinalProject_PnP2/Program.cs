﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data;
using MySql.Data.MySqlClient;
using System.Data;
using System.IO;



namespace Cahn_Jamie_FinalProject_PnP2
{
    class Program
    {
        MySqlConnection _con = null;
        Logger logFile = new Logger();

        public static List<Users> users = new List<Users>();
        public static List<Drivers> drivers = new List<Drivers>();
        public static List<Resturants> resturants = new List<Resturants>();
        public static List<Menu> menu = new List<Menu>();
        public static Users currentUser = null;
        public static Resturants currentResturant = null;
        public static Drivers currentDriver = null;
        public static List<Menu> currentOrder = new List<Menu>();


        static void Main(string[] args)
        {
            //variables
            bool running = true;
            Program instance = new Program();
            //Connection to database
            instance._con = new MySqlConnection();
            instance.Connect();


            //grab drivers
            DataTable driverData = instance.QueryDB("SELECT firstName, lastName, age, employeeNumber FROM drivers");

            foreach (DataRow dr in driverData.Rows)
            {
                drivers.Add(new Drivers(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString()));
            }


            //grab users
            DataTable usersData = instance.QueryDB("SELECT u.userName, firstName, lastName, email, address, city, state, zip, phoneNumber, password FROM userProfile u JOIN userLogin p ON u.userName = p.userName");

            foreach (DataRow dr in usersData.Rows)
            {
                users.Add(new Users(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString(), dr[7].ToString(), dr[8].ToString(), dr[9].ToString()));
            }

            //grab resturants
            DataTable resturantData = instance.QueryDB("SELECT resturantName, address, city, state, zip, phoneNumber, rating FROM resturants");

            foreach (DataRow dr in resturantData.Rows)
            {
                resturants.Add(new Resturants(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(), dr[4].ToString(), dr[5].ToString(), dr[6].ToString()));
            }

            //grab menu
            DataTable menuData = instance.QueryDB("SELECT food, price FROM menu");

            foreach (DataRow dr in menuData.Rows)
            {
                menu.Add(new Menu(dr[0].ToString(), dr[1].ToString()));
            }

            //Main Menu
            Console.WriteLine("Fast and Fresh Resturant Delivery");
            Console.WriteLine("---------------------------------");
            Console.WriteLine("1. Login");
            Console.WriteLine("2. Quit");
            Console.Write("Please make a selection: ");
            string uInput = Console.ReadLine().ToLower();

            switch (uInput)
            {
                case "1":
                case "login":
                    {
                        currentUser = instance.Login(users);
                        if (currentUser == null)
                        {
                            Utility.InvalidLogin();
                        }
                        else
                        {
                            instance.LoggedIn(currentUser);
                            instance.OrderFromResturant();
                            instance.OrderComplete();

                        }

                    }
                    break;
                case "2":
                case "quit":
                case "exit":
                    {
                        instance._con.Close();
                        running = false;
                    }
                    break;
                default:
                    {
                        Utility.Invalid();
                    }
                    break;
            }
            Utility.PressAnyKeyToContinue();

        }

        //connect to database function
        private void Connect()
        {
            BuildConString();
            try
            {
                _con.Open();
                Console.WriteLine("Connection Successful.");
            }
            catch (MySqlException e)
            {
                string msg = "";
                switch (e.Number)
                {
                    case 0:
                        {
                            msg = e.ToString();
                        }
                        break;
                    case 1042:
                        {
                            msg = "Can't Resolve Host Address.\n" + _con.ConnectionString;
                        }
                        break;
                    case 1045:
                        {
                            msg = "Invalid Username/Password";
                        }
                        break;
                    default:
                        {
                            msg = e.ToString();
                        }
                        break;
                }
                Console.WriteLine(msg);
            }
        }

        //build db connection string function
        private void BuildConString()
        {
            string ip = "";

            using (StreamReader sr = new StreamReader("C:/VFW/connect.txt"))
            {
                ip = sr.ReadLine();
            }

            string conString = $"Server={ip};";
            conString += "uid=dbsAdmin;";
            conString += "pwd=password;";
            conString += "database=testDatabase;";
            conString += "port=8889";

            _con.ConnectionString = conString;
        }

        //query the database
        DataTable QueryDB(string query)
        {
            MySqlDataAdapter adapter = new MySqlDataAdapter(query, _con);
            DataTable data = new DataTable();
            adapter.SelectCommand.CommandType = CommandType.Text;
            adapter.Fill(data);

            return data;
        }
        //Login to program
        private Users Login(List<Users> users)
        {
            Console.WriteLine("Please Type in a UserName: ");
            string userName = Console.ReadLine().ToLower();

            Console.WriteLine("Please Type in a Password: ");
            string password = Console.ReadLine().ToLower();

            for (int i = 0; i < users.Count; i++)
            {
                if (userName == users[i].UserName)
                {
                    if (password == users[i].Password)
                    {
                        logFile.UserLogin(users[i]);
                        return users[i];
                    }
                }
            }
            return null;
        }
        //"Home"
        private void LoggedIn(Users currentUser)
        {
            bool validation = true; //validation of userInput

            while (validation)
            {
                Console.Clear();
                Console.WriteLine("What Resturant Do you want to order from: ");

                for (int i = 0; i < resturants.Count; i++)
                {
                    Console.WriteLine($"{i + 1}. Name: {resturants[i].ResturantName} Rating: {resturants[i].Rating}");
                }

                Console.WriteLine("Please make a selection: ");
                string uDecision = Console.ReadLine().ToLower();



                int ValidatedInt;
                if (int.TryParse(uDecision, out ValidatedInt) && ValidatedInt >= 1 && ValidatedInt <= resturants.Count)
                {
                    currentResturant = resturants[ValidatedInt - 1];
                    validation = false;
                }
                else
                {
                    Utility.Invalid();
                }
            }
        }
        //Order an item from the resturant
        private void OrderFromResturant()
        {

            bool done = false;

                

            for (int i = 0; i < menu.Count; i++)
            {
                Console.WriteLine($"{i+1}. {menu[i].Food} | {menu[i].Price}");
            }

            while (done == false)
            {

                Console.Write("Enter food item order or enter 0 to complete order: ");

                string uInput = Console.ReadLine().ToString();

                int ValidatedInt;
                if (int.TryParse(uInput, out ValidatedInt) && ValidatedInt >= 0 && ValidatedInt <= menu.Count)
                {
                    if (ValidatedInt == 0)
                    {
                        done = true;
                    }
                    else
                    {
                        currentOrder.Add(menu[ValidatedInt - 1]);
                    }
                }
                else
                {
                    Utility.Invalid();
                }
            }

            GetDriver();

        }
        //get a random driver to pick up your food
        private void GetDriver()
        {
            Random rand = new Random();

            int randDriver = rand.Next(1, drivers.Count);

            currentDriver = drivers[randDriver - 1];
            logFile.GetDriver(currentDriver);
        }
        //complete your order and send you back to login page
        private void OrderComplete()
        {
            Console.Clear();
            Console.WriteLine("Your order has been completed.");
            Console.WriteLine($"Your order from {currentResturant.ResturantName} will be arriving soon.");
            Console.WriteLine("Your Order:");
            for (int i = 0; i < currentOrder.Count; i++)
            {
                Console.WriteLine($"{i+1}. {currentOrder[i].Food} ");
            }
            Console.WriteLine($"Your drivers name is: {currentDriver.fullName}");
            Console.WriteLine($"Thank you for shopping with us today {currentUser.FirstName} have a nice day!");
            logFile.CompletePurchase(currentDriver, currentUser, currentResturant);
            currentDriver = null;
            currentOrder = null;
            currentResturant = null;
            currentUser = null;
        }

    }
}
