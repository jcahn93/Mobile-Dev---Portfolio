﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Cahn_Jamie_FinalProject_PnP2
{
    class Logger : ILog
    {
        public void CompletePurchase(Drivers driver, Users user,  Resturants resturant)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine("------------------------");
                sw.WriteLine($"User: {user.UserName}");
                sw.WriteLine($"Resturant: {resturant.ResturantName}");
                sw.WriteLine($"Driver Assigned: {driver.DriverFirstName} {driver.DriverLastName} Employee ID: {driver.EmployeeNumber}");
                sw.WriteLine("------------------------");
            }
        }

        public void CurrentResturant(Resturants resturant)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine($"Resturant: {resturant.ResturantName}");
            }
        }

        public void Error(string msg)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine(msg);
            }
        }

        public void GetDriver(Drivers driver)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine("------------------------");
                sw.WriteLine($"Driver Assigned: {driver.DriverFirstName} {driver.DriverLastName} Employee ID: {driver.EmployeeNumber}");
                sw.WriteLine("------------------------");
            }
        }

        public void Order(string msg)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine(msg);
            }
        }

        public void UserLogin(Users user)
        {
            using (StreamWriter sw = new StreamWriter("log.txt", append: true))
            {
                sw.WriteLine("------------------------");
                sw.WriteLine($"User: {user.UserName} Logged In");
                sw.WriteLine("------------------------");
            }
        }
    }
}



