﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cahn_Jamie_FinalProject_PnP2
{
    class Drivers
    {
        public string DriverFirstName { get; set; }
        public string DriverLastName { get; set; }
        public string DriverAge { get; set; }
        public string EmployeeNumber { get; set; }
        public string fullName { get; set; }

        public Drivers(string firstName, string lastName, string age, string employeenumber)
        {
            DriverFirstName = firstName;
            DriverLastName = lastName;
            DriverAge = age;
            EmployeeNumber = employeenumber;
            fullName = DriverFirstName + " " + DriverLastName;
        }


    }
}
