﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CahnJamieWkOneExerciseTwo
{
    class Utility
    {
        public static void PauseBeforeContinuing()
        {
            Console.WriteLine("Press a key to continue.");
            Console.ReadKey();
        }

        public static void Incorrect(string thingy)
        {
            Console.WriteLine("Invalid data. " + thingy + " needs to exist.");
            PauseBeforeContinuing();

        }

        public static void Invalid()
        {
            Console.WriteLine("Invalid Input, Please Try Again.");
        }

        public static decimal HowManyHours()
        {
            return GetValue(0.00m,168m,"How many hours per week will the new employee work: ");
        }

        public static decimal HowMuchMoney()
        {
            return GetValue(0.00m, 999.99m, "How much money will the employee make per hour: ");
        }

        public static decimal GetValue(decimal min, decimal max, string message = "")
        {
            decimal validatedDec = 0;
            string input;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while ((Decimal.TryParse(input, out validatedDec) &&
                            validatedDec > min && validatedDec <= max) == false);
            return validatedDec;
        }








        public static int GetInt(int min, int max, string message = "")
        {
            int validatedInt = 0;
            string input;

            do
            {
                Console.Write(message);
                input = Console.ReadLine();
            }
            while ((Int32.TryParse(input, out validatedInt) &&
                            validatedInt > min && validatedInt <= max) == false);
            return validatedInt;
        }


    }
}
