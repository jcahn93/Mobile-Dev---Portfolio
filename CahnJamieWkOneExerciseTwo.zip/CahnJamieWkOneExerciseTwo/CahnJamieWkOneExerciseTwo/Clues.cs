﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CahnJamieWkOneExerciseTwo
{
    class Clues
    {
        string _clue = "";

        public Clues(string clue)
        {
            _clue = clue;
        }

        public string Clue
        {
            get { return _clue; }
            set { _clue = value; }
        }
    }
}
