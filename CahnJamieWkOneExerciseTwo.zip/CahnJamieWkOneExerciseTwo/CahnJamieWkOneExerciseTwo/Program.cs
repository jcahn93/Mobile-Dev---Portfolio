﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CahnJamieWkOneExerciseTwo
{
    class Program
    {
        static void Main(string[] args)
        {
            //variables
            bool running = true;
            List<Clues> clueList = new List<Clues>();
            Program instance = new Program();


            Console.WriteLine("!!Welcome to Hot or Cold!!");
            while (running)
            {
                Console.Clear();
                Console.WriteLine("1. Rules");
                Console.WriteLine("2. New Game");
                Console.WriteLine("3. Exit");
                Console.Write("Please select an item: ");
                string uInput = Console.ReadLine().ToLower();

                switch (uInput)
                {
                    case "1":
                    case "rules":
                        {
                            Console.Clear();
                            Console.WriteLine("Rules:");
                            Console.WriteLine("1. All answers must have the first letter capitalized. " +
                                "New Answers will show as wrong otherwise.");
                            Console.WriteLine("All Topics are SFW (Safe for Work).");
                            Utility.PauseBeforeContinuing();
                        }
                        break;
                    case "2":
                    case "new game":
                        {
                            instance.NewGame(clueList);
                            Utility.PauseBeforeContinuing();
                        }
                        break;
                    case "3":
                    case "exit":
                        {
                            running = false;
                        }
                        break;
                }
            }
        }

        private List<Clues> ClueList(List<Clues> clueList, string input)
        {
            if (input == "technology" || input == "1")
            {
                string clue1 = "...Head...";
                string clue2 = "...Adjustable Straps...";
                string clue3 = "...Move with your hands...";
                string clue4 = "...Rollercoasters without Rollercoasters...";
                string clue5 = "...Spooky Scary Spiders Crawling up your Arms...";
                string clue6 = "...Adjust for Clear Vision...";
                string clue7 = "...Go Ahead and Jump Off that Ledge...its safe...";
                string clue8 = "...Expensive...";
                string clue9 = "Consumer Product";
                string clue10 = "Works with Computers";
                //answer is: Oculus

                Clues tmp1 = new Clues(clue1);
                clueList.Add(tmp1);
                Clues tmp2 = new Clues(clue2);
                clueList.Add(tmp2);
                Clues tmp3 = new Clues(clue3);
                clueList.Add(tmp3);
                Clues tmp4 = new Clues(clue4);
                clueList.Add(tmp4);
                Clues tmp5 = new Clues(clue5);
                clueList.Add(tmp5);
                Clues tmp6 = new Clues(clue6);
                clueList.Add(tmp6);
                Clues tmp7 = new Clues(clue7);
                clueList.Add(tmp7);
                Clues tmp8 = new Clues(clue8);
                clueList.Add(tmp8);
                Clues tmp9 = new Clues(clue9);
                clueList.Add(tmp9);
                Clues tmp10 = new Clues(clue10);
                clueList.Add(tmp10);

                return clueList;
            }
            else if (input == "locations" || input == "2")
            {
                string clue1 = "...It's not Australia...";
                string clue2 = "...Gutentag...";
                string clue3 = "...Country...";
                string clue4 = "...Flag colors are Red and White...";
                string clue5 = "...Part of the Holy Roman Empire...";
                string clue6 = "...Not apart of NATO...";
                string clue7 = "...Birthplace of Sigmund Freud...";
                string clue8 = "...Mozart Was Born Here...";
                string clue9 = "...Downhill Skiing is popular here...";
                string clue10 = "...Don't drink the water......it has radon...";

                //answer is: Austria

                Clues tmp1 = new Clues(clue1);
                clueList.Add(tmp1);
                Clues tmp2 = new Clues(clue2);
                clueList.Add(tmp2);
                Clues tmp3 = new Clues(clue3);
                clueList.Add(tmp3);
                Clues tmp4 = new Clues(clue4);
                clueList.Add(tmp4);
                Clues tmp5 = new Clues(clue5);
                clueList.Add(tmp5);
                Clues tmp6 = new Clues(clue6);
                clueList.Add(tmp6);
                Clues tmp7 = new Clues(clue7);
                clueList.Add(tmp7);
                Clues tmp8 = new Clues(clue8);
                clueList.Add(tmp8);
                Clues tmp9 = new Clues(clue9);
                clueList.Add(tmp9);
                Clues tmp10 = new Clues(clue10);
                clueList.Add(tmp10);

                return clueList;
            }
            else if (input == "food" || input == "3")
            {
                string clue1 = "...Yum Yum in my Tum Tum...";
                string clue2 = "...You can put LITERALLY ANYTHING on it...";
                string clue3 = "...New York Style...";
                string clue4 = "...Chicago Style...";
                string clue5 = "...California ______ Kitchen...";
                string clue6 = "...Delivery Available...";
                string clue7 = "...Can be Bought Frozen...";
                string clue8 = "...On almost every block of Manhattan, NY...";
                string clue9 = "...Over the years all sorts of toppings have been added...";
                string clue10 = "...Eat me while watching the game...";

                //answer is: Pizza

                Clues tmp1 = new Clues(clue1);
                clueList.Add(tmp1);
                Clues tmp2 = new Clues(clue2);
                clueList.Add(tmp2);
                Clues tmp3 = new Clues(clue3);
                clueList.Add(tmp3);
                Clues tmp4 = new Clues(clue4);
                clueList.Add(tmp4);
                Clues tmp5 = new Clues(clue5);
                clueList.Add(tmp5);
                Clues tmp6 = new Clues(clue6);
                clueList.Add(tmp6);
                Clues tmp7 = new Clues(clue7);
                clueList.Add(tmp7);
                Clues tmp8 = new Clues(clue8);
                clueList.Add(tmp8);
                Clues tmp9 = new Clues(clue9);
                clueList.Add(tmp9);
                Clues tmp10 = new Clues(clue10);
                clueList.Add(tmp10);

                return clueList;
            }
            else if (input == "shopping" || input == "4")
            {
                string clue1 = "...Grocery Store...";
                string clue2 = "...Clothing Store...";
                string clue3 = "...Get your Birthday Cards Here...";
                string clue4 = "...Started with a Church Fire in 1895...";
                string clue5 = "...Formerly Known as The Dayton Company...";
                string clue6 = "...Over 1,800 Stores...";
                string clue7 = "...The company once helped repair the Washington Monument in Washington D.C....";
                string clue8 = "...Stores Mascot is Bullseye the dog...";
                string clue9 = "...Opened 11 Stores in 1 Day...";
                string clue10 = "...Their shopping carts weigh 20 lbs lighter then other big box store shopping carts...";

                //answer is: Target

                Clues tmp1 = new Clues(clue1);
                clueList.Add(tmp1);
                Clues tmp2 = new Clues(clue2);
                clueList.Add(tmp2);
                Clues tmp3 = new Clues(clue3);
                clueList.Add(tmp3);
                Clues tmp4 = new Clues(clue4);
                clueList.Add(tmp4);
                Clues tmp5 = new Clues(clue5);
                clueList.Add(tmp5);
                Clues tmp6 = new Clues(clue6);
                clueList.Add(tmp6);
                Clues tmp7 = new Clues(clue7);
                clueList.Add(tmp7);
                Clues tmp8 = new Clues(clue8);
                clueList.Add(tmp8);
                Clues tmp9 = new Clues(clue9);
                clueList.Add(tmp9);
                Clues tmp10 = new Clues(clue10);
                clueList.Add(tmp10);

                return clueList;

            }
            else
            {
                Utility.Invalid();
                return null;
            }
        }


        private string NewGame(List<Clues> clueList)
        {
            Console.Clear();
            Console.WriteLine("New Game");
            Console.WriteLine("Please Select a Topic: ");
            Console.WriteLine("1. Technology");
            Console.WriteLine("2. Locations");
            Console.WriteLine("3. Food");
            Console.WriteLine("4. Shopping");
            Console.WriteLine("Please make a selection: ");
            string input = Console.ReadLine().ToLower();

            switch (input)
            {
                case "1":
                case "technology":
                    {
                        ClueList(clueList, input);

                        Console.WriteLine("Technology");
                        Console.WriteLine("----------");

                        bool guessing = true;
                        int tries = 0;


                        while (guessing)
                        {
                            Console.Write("Guess: ");
                            string guess = Console.ReadLine();
                            Console.WriteLine();

                            if (guess == "Oculus")
                            {
                                Console.WriteLine("Correct!!!");
                                guessing = false;
                            }
                            else if (guess == "oculus")
                            {
                                Console.WriteLine("Close!!! It's a proper noun...");
                                tries++;
                            }
                            else
                            {
                                Console.WriteLine("Incorrect... Please Try Again!");
                                Console.WriteLine();
                                tries++;
                            }

                            if (tries % 3 == 0 && clueList.Count != 0)
                            {
                                Random x = new Random();

                                int y = x.Next(0, clueList.Count);

                                Console.WriteLine(clueList[y].Clue.ToString());

                                clueList.RemoveAt(y);
                            }

                            if (tries == 31)
                            {
                                Console.WriteLine(".......... Wow... you suck at guessing... the answer was: Oculus...");
                                guessing = false;
                            }
                        }
                        
                    }
                    break;
                case "2":
                case "locations":
                    {
                        ClueList(clueList, input);

                        Console.WriteLine("Locations");
                        Console.WriteLine("----------");

                        bool guessing = true;
                        int tries = 0;


                        while (guessing)
                        {
                            Console.Write("Guess: ");
                            string guess = Console.ReadLine();
                            Console.WriteLine();

                            if (guess == "Austria")
                            {
                                Console.WriteLine("Correct!!!");
                                guessing = false;
                            }
                            else if (guess == "austria")
                            {
                                Console.WriteLine("Close!!! It's a proper noun...");
                                tries++;
                            }
                            else
                            {
                                Console.WriteLine("Incorrect... Please Try Again!");
                                Console.WriteLine();
                                tries++;
                            }

                            if (tries % 3 == 0 && clueList.Count != 0)
                            {
                                Random x = new Random();

                                int y = x.Next(0, clueList.Count);

                                Console.WriteLine(clueList[y].Clue.ToString());

                                clueList.RemoveAt(y);
                            }

                            if (tries == 31)
                            {
                                Console.WriteLine(".......... Wow... you suck at guessing... the answer was: Austria...");
                                guessing = false;
                            }
                        }
                    }
                    break;
                case "3":
                case "food":
                    {
                        ClueList(clueList, input);

                        Console.WriteLine("Food");
                        Console.WriteLine("----");

                        bool guessing = true;
                        int tries = 0;


                        while (guessing)
                        {
                            Console.Write("Guess: ");
                            string guess = Console.ReadLine();
                            Console.WriteLine();

                            if (guess == "Pizza")
                            {
                                Console.WriteLine("Correct!!!");
                                guessing = false;
                            }
                            else if (guess == "pizza")
                            {
                                Console.WriteLine("Close!!! It's a proper noun...");
                                tries++;
                            }
                            else
                            {
                                Console.WriteLine("Incorrect... Please Try Again!");
                                Console.WriteLine();
                                tries++;
                            }

                            if (tries % 3 == 0 && clueList.Count != 0)
                            {
                                Random x = new Random();

                                int y = x.Next(0, clueList.Count);

                                Console.WriteLine(clueList[y].Clue.ToString());

                                clueList.RemoveAt(y);
                            }

                            if (tries == 31)
                            {
                                Console.WriteLine(".......... Wow... you suck at guessing... the answer was: Pizza...");
                                guessing = false;
                            }
                        }
                    }
                    break;
                case "4":
                case "shopping":
                    {
                        ClueList(clueList, input);

                        Console.WriteLine("Shopping");
                        Console.WriteLine("--------");

                        bool guessing = true;
                        int tries = 0;


                        while (guessing)
                        {
                            Console.Write("Guess: ");
                            string guess = Console.ReadLine();
                            Console.WriteLine();

                            if (guess == "Target")
                            {
                                Console.WriteLine("Correct!!!");
                                guessing = false;
                            }
                            else if (guess == "target")
                            {
                                Console.WriteLine("Close!!! It's a proper noun...");
                                tries++;
                            }
                            else
                            {
                                Console.WriteLine("Incorrect... Please Try Again!");
                                Console.WriteLine();
                                tries++;
                            }

                            if (tries % 3 == 0 && clueList.Count != 0)
                            {
                                Random x = new Random();

                                int y = x.Next(0, clueList.Count);

                                Console.WriteLine(clueList[y].Clue.ToString());

                                clueList.RemoveAt(y);
                            }

                            if (tries == 31)
                            {
                                Console.WriteLine(".......... Wow... you suck at guessing... the answer was: Target...");
                                guessing = false;
                            }
                        }
                    }
                    break;
                default:
                    {
                        Utility.Incorrect("cluelist");
                    }
                    break;
            }

            return input;
        }
    }
}